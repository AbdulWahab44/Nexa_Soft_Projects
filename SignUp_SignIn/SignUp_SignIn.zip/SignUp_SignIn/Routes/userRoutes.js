const express = require("express");
const router = express.Router();

const userController = require("../controllers/userController.js");

//for signUp user
router.post("/users", userController.signUp);

//for user login
router.post("/users/login", userController.login);

// for get single user
router.route("/users/:userId").get(userController.getSingleUser);

// for get all user
router.route("/users").get(userController.getAllUsers);

module.exports = router;