const express = require("express");
const usersRouter = require("./Routes/userRoutes.js");

const dbConnection = require("./models/connect");
dbConnection();

const PORT = 4000;
const app = express();

app.use(express.urlencoded({
    extended: true,
}));
app.use(express.json());

app.use("/api", usersRouter);

// Server listening code starts here
app.listen(PORT, ()=>console.log(`Server is running at PORT no. ${PORT}`));