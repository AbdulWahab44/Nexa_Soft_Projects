module.exports = {
    secret: "JWTSECRET"
}