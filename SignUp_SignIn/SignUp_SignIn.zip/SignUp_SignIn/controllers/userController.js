const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const Users = require("../models/user");
const { secret } = require("../constants/index");

module.exports = {
  //api for signUp
  signUp: async function (req, res) {
    try {
      const { name, email, password } = req.body;

      if (!name || !email || !password) {
        return res.status(409).send("Required fields can not be empty!");
      }

      let user = await Users.findOne({
        email,
      });

      if (user) {
        return res.status(400).send("User already exists with this email!");
      }

      const hashedPassword = await bcrypt.hash(password, 12);
      user = await Users.create({
        name,
        email,
        password: hashedPassword,
      });

      res.status(201).send({
        message: "User Added Successfully",
        user,
      });
    } catch (err) {
      console.log(err);
      res.status(500).send(err.message || "Something Went Wrong");
    }
  },

  // api for user login
  login: async function (req, res) {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(409).send("Required fields can not be empty!");
      }

      let user = await Users.findOne({
        email,
      });

      if (!user) {
        return res.status(404).send("User not found!!!");
      }
      const comparePassword = await bcrypt.compare(password, user.password);
      if (!comparePassword) {
        return res.status(409).send("Incorrect Password");
      }
      user = await user.toJSON();
      const token = await jwt.sign(user, secret);
      res.status(201).send({
        message: "User logged in Successfully",
        user,
        token,
      });
    } catch (err) {
      console.log(err);
      res.status(500).send(err.message || "Something Went Wrong");
    }
  },


  //api for getSingleUser
  getSingleUser: async (req, res) => {
    try {
      const { userId } = req.params;
      const user = await Users.findOne({
        _id: userId,
      });

      if (!user) {
        return res.status(404).send("User Not Found");
      }
      res.status(201).send(user);
    } catch (err) {
      console.log(err);
      res.status(500).send(err.message || "Something Went Wrong");
    }
  },


  //api for getAllUsers
  getAllUsers: async (req, res, next) => {
    try {
      const users = await Users.find();
      res.status(200).send(users);
    } catch (err) {
      console.log(err);
      res.status(500).send(err.message || "Something Went Wrong");
    }
  },

};
