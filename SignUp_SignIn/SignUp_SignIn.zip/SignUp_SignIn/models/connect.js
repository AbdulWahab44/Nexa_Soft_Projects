const mongoose = require("mongoose");

module.exports = async()=>{
    try{
        const {connection} = await mongoose.connect("mongodb+srv://abdulwahab9222822:vW30P8HB7IpcGm39@cluster0.5c9mlol.mongodb.net/MongoDB01");
        console.log("db Connected Successfully", connection.host);
    } catch (error){
        console.log(error);
    }
}