const express = require("express");
const connectDB = require("./db/connect");

connectDB();

const app = express();
const dotenv = require("dotenv").config();
const cors = require("cors");

const PORT = process.env.PORT || 4000;

app.use(express.json());
app.use(cors());

app.get("/", (req, res) => {
  res.send("Hello World");
});

const usersRouter = require("./routes/users");
app.use("/api", usersRouter);


// Server listening code starts here
app.listen(PORT, ()=>console.log(`Server is running at PORT no. ${PORT}`));
