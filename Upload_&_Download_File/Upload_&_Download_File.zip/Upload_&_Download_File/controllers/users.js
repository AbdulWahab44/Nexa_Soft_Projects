const User = require("../models/User");
const path = require("path");
const asyncWrapper = require("../middleware/asyncWrapper");

const getFile = async (req, res) => {
  try {
    const user = await User.find();
    res.status(200).json({ items });
  } catch (error) {
    console.log(error);
  }
};

const addFile = asyncWrapper(async (req, res) => {
  const { name } = req.body;
  const file = req.file.path;
  let user = await User.create({ name, file });
  res.status(201).json({ user });
});

const downloadFile = asyncWrapper(async (req, res) => {
  const { id } = req.params;
  let user = await User.findById(id);
  if (!user) {
    return next(new Error("No file found"));
  }
  const file = user.file;
  const filePath = path.join(__dirname, `../${file}`);
  res.download(filePath);
});

module.exports = {
  getFile,
  addFile,
  downloadFile,
};