const upload = require("../middleware/multer");
const express = require("express");

const { getFile, addFile, downloadFile } = require("../controllers/users");

const router = express.Router();

router.route("/user/file").get(getFile).post(upload.single("file"), addFile);
router.route("/download/:id").get(downloadFile);

module.exports = router;